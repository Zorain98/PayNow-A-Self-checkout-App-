package com.example.paynow;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter_cart_list extends RecyclerView.Adapter<MyAdapter_cart_list.ViewHolder>{
    private static final String TAG = "MyAdapter_cart_list";
    private ArrayList<ProductsHelperClass> list;


    //int totalamount = 0;

    public MyAdapter_cart_list( ArrayList<ProductsHelperClass> list) {
        this.list =list;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProductsHelperClass user = list.get(position);
        holder.product.setText(user.getProdname());
        holder.price.setText(user.getProdprice());
        holder.barcode.setText(user.getBarcodenum());
        //totalamount= totalamount + Integer.parseInt(user.getProdprice().toString());

    }
    @Override
    public int getItemCount() {
        return list.size();

    }
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView product, price,barcode,totalprc;
        Button deletebtn;
        private MyAdapter_cart_list adapter;
        private AdapterView listener;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            product = itemView.findViewById(R.id.tvprodnamecart);
            price = itemView.findViewById(R.id.tvprodpricecart);
            barcode = itemView.findViewById(R.id.tvbarcodecart);
            //totalprc = itemView.findViewById(R.id.prc);
            //totalprc.setText(totalamount);
            //itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    list.remove(getAdapterPosition());
                    //TotalPrice = TotalPrice - Integer.parseInt(price.getText().toString());
                    notifyItemRemoved(getAdapterPosition());
                    return true;

                }


            });


        }
        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(), (CharSequence) list.get(getAdapterPosition()), Toast.LENGTH_SHORT).show();
            }

        }
    }

