package com.example.paynow;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.example.paynow.MainActivity.TotalPrice;






public class products extends AppCompatActivity {


    // For Recycler View of the CART and products retreiving from the Database
    RecyclerView recyclerView;
    MyAdapter_cart_list myAdapter_cart_list;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    ArrayList<ProductsHelperClass> list;

    TextView brcode;
    TextView prod;
    TextView prc;
    SQLiteDatabaseExample db;
    String strcartbarcode;
    String barcodenum = "0";
    String prodname = "No Value";
    SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyyMMddHHmmssSS");
    Date myDate = new Date();
    String filename = timeStampFormat.format(myDate);
    Date c = Calendar.getInstance().getTime();
    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
    String formattedDate = df.format(c);


    boolean flag1;
    String paidmoney;




        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_products);
        brcode = findViewById(R.id.barcode);
        prod = findViewById(R.id.prod);
        prc = findViewById(R.id.prc);



        recyclerView = findViewById(R.id.cart_list);
        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        reference = rootNode.getInstance().getReference("products");

        list = new ArrayList<ProductsHelperClass>();


        myAdapter_cart_list = new MyAdapter_cart_list(list);
        recyclerView.setAdapter(myAdapter_cart_list);
        myAdapter_cart_list.notifyDataSetChanged();





/*
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot Snapshot) {
                for(DataSnapshot dataSnapshot :Snapshot.getChildren()){
                    ProductsHelperClass prod=dataSnapshot.getValue(ProductsHelperClass.class);
                   // list.add(prod);
                }
                myAdapter_cart_list.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

*/

        //  db=new SQLiteDatabaseExample(this);
        //Intent it=getIntent();
        // db.insertproducts(123467890,"Bread pack",70);


    }


    public void onClick_cartaddbtn(View v) {

        if(list.size()<1)
        {
            Toast.makeText(this, "Please Add some Products to cart!", Toast.LENGTH_SHORT).show();
            prc.setText("0");
            brcode.setText("Cart ID");
            return;
        }
        FirebaseDatabase rootNode;
        DatabaseReference reference;
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("cart");
        c = Calendar.getInstance().getTime();
        barcodenum = barcodenum + " TOTAL PRODUCTS " + list.size() + c;
        int count = 0;
        while (list.size() > count) {

            reference.child(barcodenum).push().setValue(list.get(count))
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            //Toast.makeText(getApplicationContext() , "Product Successfully added!!", Toast.LENGTH_SHORT).show();
                            //Barcode.setText("");
                            //ProdName.setText("");
                            //ProdPrice.setText("");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            //    Toast.makeText(getApplicationContext() , "Couldn't Add Product. Try again!!", Toast.LENGTH_SHORT).show();
                        }
                    })
            ;

            count++;

        }

        setTotalPrc();
        return;


    }


    // Used to get data from cart and get total price, also used to retrieve data of cart for checkout by admin
    public void setTotalPrc() {
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("cart");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                        UserHelperClass prodinfo = snapshot.getValue(UserHelperClass.class);
                    //barcodenum = prodinfo.getBarcodenum();
                    final String key = snapshot.getKey();

                    if (barcodenum.equals(key)) {
                        rootNode = FirebaseDatabase.getInstance();
                        reference = rootNode.getReference("cart").child(key);
                        reference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String barcodenum = "0";
                                String prodname = "No Value";
                                String prodprice = "0";
                                String barcodeEntered = "";
                                TotalPrice = 0;
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                    UserHelperClass prodinfo = snapshot.getValue(UserHelperClass.class);
                                    barcodenum = prodinfo.getBarcodenum();
                                    prodname = prodinfo.getProdname();
                                    prodprice = prodinfo.getProdprice();
                                    TotalPrice = TotalPrice + Integer.parseInt(prodprice);
                                    prc.setText(String.valueOf(TotalPrice));


                                    // Barcode.setText(barcodenum + barcodeEntered);
                                }
                                //TotalPrice=0;
                                brcode.setText(key);

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });


                        break;

                    } else {
                        brcode.setText("No Match");
                        TotalPrice = 0;
                        prc.setText(String.valueOf(TotalPrice));

                    }
                    // Barcode.setText(barcodenum + barcodeEntered);
                }
                barcodenum = "0";

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return;

    }


    //To add products in cart

    public void onClick(View v) {
        scancode();
        /*
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String prodprice = "0";
                String barcodeEntered = "";
                barcodeEntered = strcartbarcode;
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    UserHelperClass prodinfo = snapshot.getValue(UserHelperClass.class);
                    barcodenum = prodinfo.getBarcodenum();

                    if(barcodenum.equals(barcodeEntered) ){
                        ProductsHelperClass prod=dataSnapshot.getValue(ProductsHelperClass.class);

                        prod.setProdname(prodinfo.getProdname());
                        prod.setBarcodenum(prodinfo.getBarcodenum());
                        prod.setProdprice(prodinfo.getProdprice());
                        TotalPrice=TotalPrice+ Integer.parseInt(prod.getProdprice());
                        prc.setText(String.valueOf(TotalPrice));
                        list.add(prod);
                        myAdapter_cart_list.notifyDataSetChanged();
                        strcartbarcode="";
                        break;

                    }
                    else {

                    }
                    // Barcode.setText(barcodenum + barcodeEntered);
                }
                //TotalPrice=0;

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {


            }
        });
        return;

         */

    }


    /*
        public void onClick(View v)
        {



            boolean flag=true;
            try {

                String get_barcode = brcode.getText().toString();
                long barcod = Long.parseLong(get_barcode);
                String pdname = db.getprodname(barcod);
                String pdprice = db.getprodprice(barcod);
                prod.setText(pdname);
                //prc.setText(pdprice);
                //Integer.toString(pdprice);
                prc.setText("Rs."+ pdprice);
                paidmoney="Rs. "+pdprice;
            }
            catch(Exception e)
            {
                 flag=false;
                String error=e.toString();


                Dialog d=new Dialog(this);
                d.setTitle("Sorry.. We couldn't find any product");
                TextView tv=new TextView(this);
                tv.setText("Enter correct barcode i.e 123450, 123451 ");
                flag1=false;
                d.setContentView(tv);
                d.show();
                Toast.makeText(this, "Couldn't find any product ", Toast.LENGTH_SHORT).show();

            }
            finally
            {
                if(flag) {
                    Dialog d = new Dialog(this);
                    d.setTitle("Confirmation msg ");
                    flag1=true;
                    TextView tv = new TextView(this);
                    tv.setText("Click on Proceed To Checkout button to pay "+ paidmoney);
                    d.setContentView(tv);
                    d.show();
                }

            }
            scancode();
        }

     */
    public void onClickCheckout(View v) {
        //if (!flag1) {
        //  Toast.makeText(this, "Please enter correct barcode to purchase any product", Toast.LENGTH_SHORT).show();
        //return;
        //}
        Intent it = new Intent(products.this, final_activity.class);
        if (brcode.getText().toString().matches("No Match")) {
            Toast.makeText(this, "Please Add some Products to cart!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (brcode.getText().toString().matches("Cart ID")) {
            if(list.size()<1)
            {
                Toast.makeText(this, "Please Add some Products to cart!", Toast.LENGTH_SHORT).show();
                prc.setText("0");
                return;

            }
            Toast.makeText(this, "Please Click on Produce Cart before proceeding!", Toast.LENGTH_SHORT).show();
            return;
        }
        if(list.size()<1)
        {
            Toast.makeText(this, "Please Add some Products to cart!", Toast.LENGTH_SHORT).show();
            prc.setText("0");
            return;

        }


        it.putExtra("cartid", brcode.getText().toString());
        it.putExtra("totalamount", "Total : Rs." + (prc.getText().toString()) + "   Products : " +(String.valueOf(list.size())));

        startActivity(it);

    }


    private void scancode() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(CaptureAct.class);
        integrator.setOrientationLocked(false);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scanning Code");
        integrator.initiateScan();
        return;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (((IntentResult) result).getContents() != null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(result.getContents());
                builder.setTitle("Scanning Result");
                strcartbarcode = result.getContents();
                builder.setPositiveButton("Scan Again", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        scancode();

                    }
                }).setNegativeButton("finish", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

// Code to add products from database to recycler view cart list
                        reference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String prodprice = "0";
                                String barcodeEntered = "";
                                barcodeEntered = strcartbarcode;
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                    UserHelperClass prodinfo = snapshot.getValue(UserHelperClass.class);
                                    barcodenum = prodinfo.getBarcodenum();

                                    if (barcodenum.equals(barcodeEntered)) {
                                        ProductsHelperClass prod = dataSnapshot.getValue(ProductsHelperClass.class);

                                        prod.setProdname(prodinfo.getProdname());
                                        prod.setBarcodenum(prodinfo.getBarcodenum());
                                        prod.setProdprice(prodinfo.getProdprice());
                                        TotalPrice = TotalPrice + Integer.parseInt(prod.getProdprice());
                                        prc.setText(String.valueOf(TotalPrice));
                                        list.add(prod);
                                        myAdapter_cart_list.notifyDataSetChanged();
                                        brcode.setText("Cart ID");
                                        strcartbarcode = "";
                                        break;

                                    } else {

                                    }
                                    // Barcode.setText(barcodenum + barcodeEntered);
                                }
                                //TotalPrice=0;

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {


                            }
                        });

                        //finish();
                    }


                });
                AlertDialog dialog = builder.create();
                dialog.show();

            } else {
                Toast.makeText(this, "No Results ", Toast.LENGTH_LONG).show();
            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
        return;
    }
}





