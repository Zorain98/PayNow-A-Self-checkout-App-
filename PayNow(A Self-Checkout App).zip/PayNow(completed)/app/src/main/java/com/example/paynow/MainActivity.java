package com.example.paynow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    SQLiteDatabaseExample db;
    public static int TotalPrice = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db=new SQLiteDatabaseExample(this);
        db.insertproducts(123450,"Cereals pack",300);
        db.insertproducts(123451,"Bread pack",70);
        db.insertproducts(123452,"Dozen Eggs",120);
        db.insertproducts(123453,"Milk litre pack",100);
        db.insertproducts(123454,"Cookies pack",50);
        db.insertproducts(123455,"Cheese pack",150);
        db.insertproducts(123456,"Honey Bottle",600);
        db.insertproducts(123457,"Yogurt pack ",130);
        db.insertproducts(123458,"Butter Bottle",250);
        db.insertproducts(123459,"Jam bottle",350);

    }
    public void onClick1(View v)
    {



        Intent it=new Intent(MainActivity.this,Login_activity.class);
        startActivity(it);

    }
    public void onClick2(View v)
    {
        Intent it=new Intent(MainActivity.this,AdminLogin.class);
        startActivity(it);
    }
}

