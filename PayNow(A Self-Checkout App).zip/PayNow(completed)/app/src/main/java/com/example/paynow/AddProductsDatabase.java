package com.example.paynow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.HashMap;


public class AddProductsDatabase extends AppCompatActivity {
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    EditText Barcode,ProdName,ProdPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_products_database);
        Barcode=findViewById(R.id.ccname_edit);
        ProdName=findViewById(R.id.ccnumber);
        ProdPrice=findViewById(R.id.expirydate);
        Intent it=getIntent();
    }



    //TO SIGN OUT



    public void onClickSignout(View v)
    {
        Toast.makeText(this, "Signing Out!!", Toast.LENGTH_SHORT).show();
        Intent it=new Intent(AddProductsDatabase.this,MainActivity.class);
        startActivity(it);
        finish();
    }




    // BARCODE SCANNER




    public void onClickScan(View v){
        scancode();

    }

    private void scancode() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(CaptureAct.class);
        integrator.setOrientationLocked(false);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scanning Code");
        integrator.initiateScan();
        return;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (((IntentResult) result).getContents() != null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                Barcode.setText(result.getContents());
                builder.setMessage(result.getContents() );
                builder.setTitle("Scanning Result");
                builder.setPositiveButton("Scan Again", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        scancode();

                    }
                }).setNegativeButton("finish", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //finish();
                    }
                });
                AlertDialog dialog= builder.create();
                dialog.show();

            }
            else{
                Toast.makeText(this,"No Results ", Toast.LENGTH_LONG).show();
            }

        }
        else{
            super.onActivityResult(requestCode, resultCode, data);
        }
    }




    //TO ADD NEW DATA IN DATABASE




    public void onClickCheckout(View v)
    {
        String n=Barcode.getText().toString();
        if (n.matches("")) {
            Toast.makeText(this, "Please Enter Barcode Number", Toast.LENGTH_SHORT).show();
            return;
        }
        String c=ProdName.getText().toString();
        if (c.matches("")) {
            Toast.makeText(this, "Please Enter Product Name", Toast.LENGTH_SHORT).show();
            return;
        }
        String e=ProdPrice.getText().toString();
        if (e.matches("")) {
            Toast.makeText(this, "Please Enter Product Price", Toast.LENGTH_SHORT).show();
            return;
        }
        rootNode= FirebaseDatabase.getInstance();
        reference=rootNode.getReference("products");
        String barcode=Barcode.getText().toString();
        String prod_name=ProdName.getText().toString();
        String prod_price=ProdPrice.getText().toString();

        UserHelperClass userhelperclass_products =new UserHelperClass(barcode,prod_name,prod_price);
        reference.child(barcode).setValue(userhelperclass_products)
        .addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getApplicationContext() , "Product Successfully added!!", Toast.LENGTH_SHORT).show();
                Barcode.setText("");
                ProdName.setText("");
                ProdPrice.setText("");
            }
        })
        .addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext() , "Couldn't Add Product. Try again!!", Toast.LENGTH_SHORT).show();
            }
        })
        ;



    }




    //TO UPDATE DATA IN DATABASE



    public void onClickUpdate(View v){
        String n=Barcode.getText().toString();
        if (n.matches("")) {
            Toast.makeText(this, "Please Enter Barcode Number", Toast.LENGTH_SHORT).show();
            return;
        }
        String c=ProdName.getText().toString();
        if (c.matches("")) {
            Toast.makeText(this, "Please Enter Product Name", Toast.LENGTH_SHORT).show();
            return;
        }
        String e=ProdPrice.getText().toString();
        if (e.matches("")) {
            Toast.makeText(this, "Please Enter Product Price", Toast.LENGTH_SHORT).show();
            return;
        }
        HashMap<String,Object> hashMap = new HashMap<>();
        hashMap.put("barcodenum", Barcode.getText().toString());
        hashMap.put("prodname", ProdName.getText().toString());
        hashMap.put("prodprice", ProdPrice.getText().toString());

        updateprodcode(Barcode.getText().toString(), hashMap);


        return;

    }
    public void updateprodcode(String key, HashMap<String, Object> hasMap){
        reference.child(key).updateChildren(hasMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getApplicationContext() , "Updated Successfully!!", Toast.LENGTH_SHORT).show();
                Barcode.setText("");
                ProdName.setText("");
                ProdPrice.setText("");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext() , "Can't Update. Try again!!", Toast.LENGTH_SHORT).show();
                    }
                })
        ;
        return;
    }




    //To Remove DATA from DATABASE


    public void onClickRemove(View v){
        rootNode= FirebaseDatabase.getInstance();
        reference=rootNode.getReference("products");
        String barcodestring=Barcode.getText().toString();
        if (barcodestring.matches("")) {
            Toast.makeText(this, "Please Enter Barcode Number", Toast.LENGTH_SHORT).show();
            return;
        }
        removeprodcode(Barcode.getText().toString());


    }
    public void removeprodcode(String key){
        reference.child(key).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getApplicationContext() , "Deleted Successfully!!", Toast.LENGTH_SHORT).show();
                Barcode.setText("");
                ProdName.setText("");
                ProdPrice.setText("");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext() , "Can't Delete. Try again!!", Toast.LENGTH_SHORT).show();
                    }
                })
        ;
    return;
    }



    //TO READ DATA FROM DATABASE


    public void onClickViewProd(View v){
        String n=Barcode.getText().toString();
        if (n.matches("")) {
            Toast.makeText(this, "Please Enter Barcode Number", Toast.LENGTH_SHORT).show();
            return;
        }
        rootNode= FirebaseDatabase.getInstance();
        reference=rootNode.getReference("products");
        viewprodcode();
        String prodname=ProdName.getText().toString();
        if (n.matches("")) {
            Toast.makeText(this, "No Record Found!!", Toast.LENGTH_SHORT).show();
            return;
        }

    }
    public void viewprodcode(){
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String barcodenum = "0";
                String prodname = "No Value";
                String prodprice = "0";
                String barcodeEntered = "";
                barcodeEntered = Barcode.getText().toString();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    UserHelperClass prodinfo = snapshot.getValue(UserHelperClass.class);
                    barcodenum = prodinfo.getBarcodenum();

                    if(barcodenum.equals(barcodeEntered) ){
                        prodname = prodinfo.getProdname();
                        prodprice = prodinfo.getProdprice();
                        ProdName.setText(prodname);
                        ProdPrice.setText(prodprice);
                        break;
                    }
                    else {
                        ProdName.setText("");
                        ProdPrice.setText("");

                    }
                    // Barcode.setText(barcodenum + barcodeEntered);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                ProdName.setText("No Record !");

            }
        });
        return;

    }



}












