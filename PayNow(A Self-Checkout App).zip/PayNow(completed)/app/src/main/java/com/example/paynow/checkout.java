package com.example.paynow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class checkout extends AppCompatActivity {



    EditText Name,cardnum,expdate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        Name=findViewById(R.id.ccname_edit);
        cardnum=findViewById(R.id.ccnumber);
        expdate=findViewById(R.id.expirydate);
        Intent it=getIntent();
    }
    public void onClickCheckout(View v)
    {
        String n=Name.getText().toString();
        if (n.matches("")) {
            Toast.makeText(this, "Please Enter your name", Toast.LENGTH_SHORT).show();
            return;
        }
        String c=cardnum.getText().toString();
        if (c.matches("")) {
            Toast.makeText(this, "Please Enter your card number", Toast.LENGTH_SHORT).show();
            return;
        }
        String e=expdate.getText().toString();
        if (e.matches("")) {
            Toast.makeText(this, "Please Enter expiry date of card", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent it=new Intent(checkout.this,final_activity.class);
        startActivity(it);
        finish();
    }
}
