package com.example.paynow;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

public class SQLiteDatabaseExample extends SQLiteOpenHelper {

    private static final String DATABASE_NAME="Product_info";

    private static final int DATABASE_Version=1;

    private static final String TABLE_PRODUCT="tblproduct";

    private static final String Key_barcode="barcode";
    private static final String Key_prodname="Product";
    private static final String Key_prodprice="price";


    SQLiteDatabase db;
    public SQLiteDatabaseExample(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BARCODE_TABLE = "CREATE TABLE " + TABLE_PRODUCT + "( " + Key_barcode + " INTEGER PRIMARY KEY," + Key_prodname + " TEXT, " + Key_prodprice + " INTEGER );";



        db.execSQL(CREATE_BARCODE_TABLE);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCT);
        //onCreate(db);

    }

    public void insertproducts(int i, String p_name, int i1) {
        db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(Key_barcode,i);
        cv.put(Key_prodname,p_name);
        cv.put(Key_prodprice,i1);
        db.insert(TABLE_PRODUCT,null,cv);
         // return
        return;



    }

    public String getprodname(long barcod) {
        db=getReadableDatabase();
        String [] column=new String[] {Key_barcode,Key_prodname,Key_prodprice};
        Cursor c=db.query(TABLE_PRODUCT,column,Key_barcode + " = " + barcod,null,null,null,null);
        if(c!=null)
        {
            c.moveToFirst();
            String name=c.getString(1);
            return name;
        }
        return null;


        
    }

    public String getprodprice(long barcod) {
        db=getReadableDatabase();
        String [] column=new String[] {Key_barcode,Key_prodname,Key_prodprice};
        Cursor c=db.query(TABLE_PRODUCT,column,Key_barcode + " = " + barcod,null,null,null,null);
        if(c!=null)
        {
            c.moveToFirst();
            String name=c.getString(2);
            return name;
        }
        return null;

    }
}
