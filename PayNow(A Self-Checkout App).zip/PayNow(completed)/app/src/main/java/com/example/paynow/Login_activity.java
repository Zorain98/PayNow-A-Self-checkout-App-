package com.example.paynow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login_activity extends AppCompatActivity {

    EditText logMail,pasword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);
        logMail=findViewById(R.id.email_edit_login);
        pasword=findViewById(R.id.password_edit_login);
        Intent it=getIntent();
    }

    public void onClick1(View v)
    {

        Intent it=new Intent(Login_activity.this,Registeration_activity.class);
        startActivity(it);
        finish();
    }
    public void onClickLogin(View v)
    {
        String c=logMail.getText().toString();
        if (c.matches("")) {
            Toast.makeText(this, "Please Enter your login mail", Toast.LENGTH_SHORT).show();
            return;
        }
        String p=pasword.getText().toString();
        if (p.matches("")) {
            Toast.makeText(this, "Please Enter the password to log in", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent it=new Intent(Login_activity.this,products.class);
        startActivity(it);
        finish();
    }
    public void onClickGuestMode(View v)
    {

        Intent it=new Intent(Login_activity.this,products.class);
        startActivity(it);
        finish();
    }

}
