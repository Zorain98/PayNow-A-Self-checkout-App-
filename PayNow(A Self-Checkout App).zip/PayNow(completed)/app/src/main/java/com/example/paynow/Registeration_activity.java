package com.example.paynow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registeration_activity extends AppCompatActivity {


    FirebaseDatabase rootNode;
    DatabaseReference reference;
    EditText regFname,regLname,regMail,regPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeration_activity);
        regFname=findViewById(R.id.barcodenum_edit);
        regLname=findViewById(R.id.prodname_edit);
        regMail=findViewById(R.id.prodprice_edit);
        regPassword=findViewById(R.id.password_edit_reg);
        Intent it=getIntent();
        rootNode= FirebaseDatabase.getInstance();
        reference=rootNode.getReference("user");
    }
    public void onClicRegister(View v)
    {
        String f=regFname.getText().toString();
        if (f.matches("")) {
            Toast.makeText(this, "Enter first name", Toast.LENGTH_SHORT).show();
            return;
        }
        String m=regMail.getText().toString();
        if (m.matches("")) {
            Toast.makeText(this, "Please Enter your mail", Toast.LENGTH_SHORT).show();
            return;
        }
        String p=regPassword.getText().toString();
        if (p.matches("")) {
            Toast.makeText(this, "Set password please", Toast.LENGTH_SHORT).show();
            return;
        }

        String f_name=regFname.getText().toString();
        String l_name=regLname.getText().toString();
        String e_mail=regMail.getText().toString();
        String password=regPassword.getText().toString();

        UserHelperClass userhelperclass=new UserHelperClass(f_name,l_name,e_mail,password);
        reference.child(f_name).setValue(userhelperclass);
        Intent it=new Intent(Registeration_activity.this,products.class);
        startActivity(it);
        finish();
    }
}
