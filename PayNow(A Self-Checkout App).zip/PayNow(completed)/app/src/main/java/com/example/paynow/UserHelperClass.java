package com.example.paynow;

//User Helper Class for Registration of new users/clients


public class UserHelperClass {
    String fname,lname,mail,password;
    String barcodenum,prodname,prodprice;

    public UserHelperClass() {

    }
    public UserHelperClass(String fname, String lname, String mail, String password) {
        this.fname = fname;
        this.lname = lname;
        this.mail = mail;
        this.password = password;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }







   //Helper Class for Registering/Adding Products by Adminitrator



    public UserHelperClass(String barcode_num,String prodname, String prodprice) {
        this.prodname = prodname;
        this.barcodenum = barcode_num;
        this.prodprice = prodprice;
    }
    public UserHelperClass(String prodname, String prodprice) {
        this.prodname = prodname;
        this.prodprice = prodprice;
    }

    public String getProdname() {
        return prodname;
    }

    public void setProdname(String prodname) {
        this.prodname = prodname;
    }

    public String getProdprice() {
        return prodprice;
    }

    public void setProdprice(String prodprice) {
        this.prodprice = prodprice;
    }

    public String getBarcodenum() {
        return barcodenum;
    }

    public void setBarcodenum(String barcodenum) {
        this.barcodenum = barcodenum;
    }

}
