package com.example.paynow;

public class ProductsHelperClass {
    String barcodenum,prodname,prodprice;


    public ProductsHelperClass() {

        }


        //Helper Class for Registering/Adding Products by Adminitrator



        public ProductsHelperClass(String prodname, String prodprice) {
            this.prodname = prodname;
            this.prodprice = prodprice;
            this.barcodenum= barcodenum;

        }

        public String getProdname() {
            return prodname;
        }

        public void setProdname(String prodname) {
            this.prodname = prodname;
        }

        public String getProdprice() {
            return prodprice;
        }

        public void setProdprice(String prodprice) {
            this.prodprice = prodprice;
        }

    public String getBarcodenum() {
        return barcodenum;
    }

    public void setBarcodenum(String barcodenum) {
        this.barcodenum = barcodenum;
    }


}

