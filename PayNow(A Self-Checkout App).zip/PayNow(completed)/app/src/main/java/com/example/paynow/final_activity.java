package com.example.paynow;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;


public class final_activity extends AppCompatActivity {

    private ImageView qrImage;
    private String inputValue;
    private String savePath = Environment.getExternalStorageDirectory().getPath() + "/QRCode/";
    private Bitmap bitmap;
    private BarcodeEncoder barcodeEncoder;
    private AppCompatActivity activity;
    private TextView tv_total_final_act;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_activity);
        Intent it=getIntent();
        inputValue= it.getStringExtra("cartid");
        tv_total_final_act=findViewById(R.id.tv_total_final_act);
        tv_total_final_act.setText((it.getStringExtra("totalamount")));
        qrImage = findViewById(R.id.qr_image);
        activity = this;

        findViewById(R.id.generate_barcode).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputValue.trim();
                if (inputValue.length() > 0) {
                    MultiFormatWriter writer = new MultiFormatWriter();
                    try {
                        BitMatrix matrix = writer.encode(inputValue, BarcodeFormat.QR_CODE, 700, 700);
                        BarcodeEncoder encoder = new BarcodeEncoder();
                        Bitmap bitmap = encoder.createBitmap(matrix);
                        qrImage.setImageBitmap(bitmap);

                        InputMethodManager manager = (InputMethodManager) getSystemService(
                                Context.INPUT_METHOD_SERVICE
                        );
                        //manager.hideSoftInputFromWindow(edtValue.getApplicationWindowToken(), 0);

                    } catch (WriterException e) {
                        e.printStackTrace();
                    }
                }

            }
        });

/*


        findViewById(R.id.btn_jazzcash).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(Intent.ACTION_ALL_APPS);

// Always use string resources for UI text.
// This says something like "Share this photo with"
                String title = "http:/google.com";
// Create intent to show chooser
                //Intent chooser = Intent.createChooser(intent, title);
                Intent chooser = getPackageManager().getLaunchIntentForPackage("com.techlogix.mobilinkcustomer");

// Try to invoke the intent.
                try {
                    if(chooser != null) {
                        startActivity(chooser);

                    }
                    else{
                        Toast.makeText(final_activity.this,"NO results",Toast.LENGTH_SHORT ).show();
                    }

                } catch (ActivityNotFoundException e) {
                    // Define what your app should do if no activity can handle the intent.
                    //Toast.makeText(this, "No Results ", Toast.LENGTH_LONG).show()
                }


            }
        });






        findViewById(R.id.btn_easypaisa).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(Intent.ACTION_ALL_APPS);

                //Intent chooser = Intent.createChooser(intent, title);
                Intent chooser = getPackageManager().getLaunchIntentForPackage("pk.com.telenor.phoenix");

// Try to invoke the intent.
                try {
                    if(chooser != null) {
                        startActivity(chooser);

                    }
                    else{
                        Toast.makeText(final_activity.this,"NO results",Toast.LENGTH_SHORT ).show();
                    }

                } catch (ActivityNotFoundException e) {
                    // Define what your app should do if no activity can handle the intent.
                    //Toast.makeText(this, "No Results ", Toast.LENGTH_LONG).show()
                }


            }
        });
*/
    }
}
